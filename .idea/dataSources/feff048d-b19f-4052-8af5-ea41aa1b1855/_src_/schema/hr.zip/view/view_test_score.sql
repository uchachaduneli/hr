CREATE VIEW view_test_score AS
  SELECT
    `v`.`test_id`                                                                                                AS `test_id`,
    `q`.`question_type_id`                                                                                       AS `question_type_id`,
    `qt`.`name`                                                                                                  AS `question_type_name`,
    `v`.`candidate_id`                                                                                           AS `candidate_id`,
    `v`.`department_id`                                                                                          AS `department_id`,
    `t`.`name`                                                                                                   AS `department_name`,
    `p`.`first_name`                                                                                             AS `candidate_first_name`,
    `p`.`last_name`                                                                                              AS `candidate_last_name`,
    (SELECT count(`vp`.`id`)
     FROM `hr`.`vote_pair` `vp`
     WHERE ((`vp`.`test_id` = `v`.`test_id`) AND (`vp`.`candidate_id` <> `vp`.`voter_id`) AND
            ((`vp`.`candidate_id` = `v`.`candidate_id`) OR (`vp`.`department_id` =
                                                            `v`.`department_id`))))                              AS `voter_full_count`,
    (SELECT count(DISTINCT `vot`.`voter_id`)
     FROM `hr`.`vote` `vot`
     WHERE ((`vot`.`test_id` = `v`.`test_id`) AND (`vot`.`candidate_id` <> `vot`.`voter_id`) AND
            ((`vot`.`candidate_id` = `v`.`candidate_id`) OR (`vot`.`department_id` =
                                                             `v`.`department_id`))))                             AS `voter_current_count`,
    sum((CASE WHEN (ifnull(`v`.`department_id`, 0) <> 0)
      THEN (SELECT sum(`s`.`max_score`)
            FROM `hr`.`view_max_score` `s`
            WHERE ((`s`.`test_id` = `v`.`test_id`) AND (`q`.`question_type_id` = `s`.`question_type_id`)))
         WHEN (`p`.`position_id` <= 6)
           THEN (SELECT sum(`s`.`max_score`)
                 FROM `hr`.`view_max_score` `s`
                 WHERE ((`s`.`test_id` = `v`.`test_id`) AND (`q`.`question_type_id` = `s`.`question_type_id`) AND
                        ((`s`.`position_id` = `p`.`position_id`) OR (`s`.`position_id` = 1))))
         WHEN (`p`.`position_id` > 6)
           THEN (SELECT sum(`s`.`max_score`)
                 FROM `hr`.`view_max_score` `s`
                 WHERE ((`s`.`test_id` = `v`.`test_id`) AND (`s`.`question_type_id` = `q`.`question_type_id`) AND
                        (`s`.`position_id` IN
                         (1, 2)))) END))                                                                         AS `max_score`,
    ifnull((CASE WHEN (ifnull(`v`.`department_id`, 0) <> 0)
      THEN (SELECT sum(`vt`.`score`)
            FROM `hr`.`view_vote_detail` `vt`
            WHERE ((`vt`.`test_id` = `v`.`test_id`) AND (`vt`.`department_id` = `v`.`department_id`)))
            WHEN (ifnull(`v`.`candidate_id`, 0) <> 0)
              THEN (SELECT sum(`vt`.`score`)
                    FROM `hr`.`view_vote_detail` `vt`
                    WHERE ((`vt`.`test_id` = `v`.`test_id`) AND (`vt`.`candidate_id` <> `vt`.`voter_id`) AND
                           (`q`.`question_type_id` = `vt`.`question_type_id`) AND
                           (`vt`.`candidate_id` = `v`.`candidate_id`))) END),
           0)                                                                                                    AS `real_score`,
    ifnull((SELECT sum(`vv`.`score`)
            FROM `hr`.`view_vote` `vv`
            WHERE ((`vv`.`candidate_id` = `v`.`candidate_id`) AND (`vv`.`candidate_id` = `vv`.`voter_id`) AND
                   (`vv`.`test_id` = `v`.`test_id`) AND (`q`.`question_type_id` = `vv`.`question_type_id`))),
           0)                                                                                                    AS `self_score`,
    `p`.`structure_id`                                                                                           AS `candidate_structure_id`
  FROM ((((`hr`.`vote_pair` `v` LEFT JOIN `hr`.`view_test_question_type` `q`
      ON (((`v`.`test_id` = `q`.`test_id`) AND (`q`.`question_type_id` <> 2)))) LEFT JOIN `hr`.`question_type` `qt`
      ON ((`q`.`question_type_id` = `qt`.`id`))) LEFT JOIN `hr`.`personal` `p`
      ON ((`v`.`candidate_id` = `p`.`id`))) LEFT JOIN `hr`.`structure` `t` ON ((`v`.`department_id` = `t`.`id`)))
  WHERE (`v`.`candidate_id` <> `v`.`voter_id`)
  GROUP BY `v`.`test_id`, `q`.`question_type_id`, `v`.`candidate_id`, `v`.`department_id`, `p`.`first_name`,
    `p`.`last_name`
  ORDER BY `v`.`test_id`, `v`.`candidate_id`, `q`.`question_type_id`;
