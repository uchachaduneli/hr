CREATE VIEW view_max_score AS
  SELECT
    `q`.`test_id`          AS `test_id`,
    `q`.`question_type_id` AS `question_type_id`,
    `q`.`id`               AS `question_id`,
    `q`.`position_id`      AS `position_id`,
    max(`aa`.`score`)      AS `max_score`
  FROM ((`hr`.`question` `q`
    JOIN `hr`.`answer_group` `g` ON ((`q`.`answer_group_id` = `g`.`id`))) JOIN `hr`.`answer` `aa`
      ON ((`g`.`id` = `aa`.`group_id`)))
  GROUP BY `q`.`test_id`, `q`.`question_type_id`, `q`.`id`, `q`.`position_id`;
