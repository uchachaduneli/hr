CREATE VIEW view_self_score AS
  SELECT
    `v`.`test_id`                                                                                                AS `test_id`,
    `q`.`question_type_id`                                                                                       AS `question_type_id`,
    `qt`.`name`                                                                                                  AS `question_type_name`,
    `v`.`candidate_id`                                                                                           AS `candidate_id`,
    `v`.`department_id`                                                                                          AS `department_id`,
    `t`.`name`                                                                                                   AS `department_name`,
    `p`.`first_name`                                                                                             AS `candidate_first_name`,
    `p`.`last_name`                                                                                              AS `candidate_last_name`,
    sum((CASE WHEN (ifnull(`v`.`department_id`, 0) <> 0)
      THEN (SELECT sum(`s`.`max_score`)
            FROM `hr`.`view_max_score` `s`
            WHERE ((`s`.`test_id` = `v`.`test_id`) AND (`q`.`question_type_id` = `s`.`question_type_id`)))
         WHEN (`p`.`position_id` <= 6)
           THEN (SELECT sum(`s`.`max_score`)
                 FROM `hr`.`view_max_score` `s`
                 WHERE ((`s`.`test_id` = `v`.`test_id`) AND (`q`.`question_type_id` = `s`.`question_type_id`) AND
                        ((`s`.`position_id` = `p`.`position_id`) OR (`s`.`position_id` = 1))))
         WHEN (`p`.`position_id` > 6)
           THEN (SELECT sum(`s`.`max_score`)
                 FROM `hr`.`view_max_score` `s`
                 WHERE ((`s`.`test_id` = `v`.`test_id`) AND (`s`.`question_type_id` = `q`.`question_type_id`) AND
                        (`s`.`position_id` IN
                         (1, 2)))) END))                                                                         AS `max_score`,
    ifnull((SELECT sum(`vv`.`score`)
            FROM `hr`.`view_vote_detail` `vv`
            WHERE ((`vv`.`candidate_id` = `v`.`candidate_id`) AND (`vv`.`candidate_id` = `vv`.`voter_id`) AND
                   (`vv`.`test_id` = `v`.`test_id`) AND (`q`.`question_type_id` = `vv`.`question_type_id`))),
           0)                                                                                                    AS `self_score`,
    `p`.`structure_id`                                                                                           AS `candidate_structure_id`
  FROM (((
      (`hr`.`vote_pair` `v` LEFT JOIN `hr`.`view_test_question_type` `q` ON ((`v`.`test_id` = `q`.`test_id`))) LEFT JOIN
      `hr`.`question_type` `qt` ON ((`q`.`question_type_id` = `qt`.`id`))) LEFT JOIN `hr`.`personal` `p`
      ON ((`v`.`candidate_id` = `p`.`id`))) LEFT JOIN `hr`.`structure` `t` ON ((`v`.`department_id` = `t`.`id`)))
  WHERE (`v`.`voter_id` = `v`.`candidate_id`)
  GROUP BY `v`.`test_id`, `v`.`candidate_id`, `v`.`department_id`, `q`.`question_type_id`, `p`.`first_name`,
    `p`.`last_name`
  ORDER BY `v`.`test_id`, `v`.`candidate_id`, `v`.`department_id`, `q`.`question_type_id`;
