CREATE VIEW view_vote_detail AS
  SELECT
    `v`.`test_id`          AS `test_id`,
    `q`.`question_type_id` AS `question_type_id`,
    `v`.`candidate_id`     AS `candidate_id`,
    `v`.`department_id`    AS `department_id`,
    `v`.`voter_id`         AS `voter_id`,
    `p`.`first_name`       AS `candidate_first_name`,
    `p`.`last_name`        AS `candidate_last_name`,
    `s`.`name`             AS `department_name`,
    `a`.`score`            AS `score`,
    `v`.`answer_id`        AS `answer_id`
  FROM ((((`hr`.`vote` `v`
    JOIN `hr`.`question` `q` ON ((`q`.`id` = `v`.`question_id`))) JOIN `hr`.`answer` `a`
      ON ((`a`.`id` = `v`.`answer_id`))) LEFT JOIN `hr`.`personal` `p` ON ((`v`.`candidate_id` = `p`.`id`))) LEFT JOIN
    `hr`.`structure` `s` ON ((`v`.`department_id` = `s`.`id`)));
