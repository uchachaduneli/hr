CREATE VIEW view_personal AS
  SELECT
    `p`.`id`                                       AS `id`,
    `p`.`structure_id`                             AS `structure_id`,
    `p`.`position_id`                              AS `position_id`,
    `p`.`first_name`                               AS `first_name`,
    `p`.`last_name`                                AS `last_name`,
    `p`.`mail`                                     AS `mail`,
    `p`.`birth_date`                               AS `birth_date`,
    `p`.`pid_number`                               AS `pid_number`,
    concat(`p`.`first_name`, ' ', `p`.`last_name`) AS `full_name`,
    `s`.`name`                                     AS `position_name`,
    `s`.`position`                                 AS `position`,
    `p`.`status_id`                                AS `status_id`
  FROM (`hr`.`personal` `p`
    JOIN `hr`.`position` `s` ON ((`p`.`position_id` = `s`.`id`)));
