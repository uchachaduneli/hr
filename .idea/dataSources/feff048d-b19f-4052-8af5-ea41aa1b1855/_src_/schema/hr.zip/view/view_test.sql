CREATE VIEW view_test AS
  SELECT
    `t`.`id`               AS `id`,
    `t`.`name`             AS `name`,
    `t`.`description`      AS `description`,
    `t`.`active_status_id` AS `active_status_id`,
    `s`.`name`             AS `active_status_name`,
    `t`.`type_id`          AS `type_id`,
    `tt`.`name`            AS `type_name`,
    `t`.`organisation_id`  AS `organisation_id`
  FROM ((`hr`.`test` `t`
    JOIN `hr`.`test_active_status` `s` ON ((`t`.`active_status_id` = `s`.`id`))) JOIN `hr`.`test_type` `tt`
      ON ((`t`.`type_id` = `tt`.`id`)));
