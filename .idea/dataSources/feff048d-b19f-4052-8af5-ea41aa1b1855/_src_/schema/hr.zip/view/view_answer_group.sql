CREATE VIEW view_answer_group AS
  SELECT
    `g`.`id`          AS `id`,
    `g`.`name`        AS `name`,
    `g`.`description` AS `description`,
    `g`.`type_id`     AS `type_id`,
    `t`.`name`        AS `type_name`
  FROM (`hr`.`answer_group` `g`
    JOIN `hr`.`answer_type` `t` ON ((`g`.`type_id` = `t`.`id`)));
