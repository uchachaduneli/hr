CREATE VIEW view_question AS
  SELECT
    `q`.`id`               AS `id`,
    `q`.`test_id`          AS `test_id`,
    `q`.`title`            AS `title`,
    `q`.`description`      AS `description`,
    `q`.`answer_group_id`  AS `answer_group_id`,
    `q`.`question_type_id` AS `question_type_id`,
    `t`.`name`             AS `question_type_name`,
    `g`.`name`             AS `answer_group_name`,
    `q`.`position_id`      AS `position_id`,
    `p`.`name`             AS `position_name`
  FROM (((`hr`.`question` `q`
    JOIN `hr`.`answer_group` `g` ON ((`q`.`answer_group_id` = `g`.`id`))) JOIN `hr`.`question_type` `t`
      ON ((`q`.`question_type_id` = `t`.`id`))) JOIN `hr`.`question_position` `p` ON ((`q`.`position_id` = `p`.`id`)));
