CREATE VIEW view_vote AS
  SELECT
    `v`.`test_id`          AS `test_id`,
    `q`.`question_type_id` AS `question_type_id`,
    `v`.`candidate_id`     AS `candidate_id`,
    `v`.`department_id`    AS `department_id`,
    `v`.`question_id`      AS `question_id`,
    `v`.`answer_id`        AS `answer_id`,
    `p`.`first_name`       AS `candidate_first_name`,
    `p`.`last_name`        AS `candidate_last_name`,
    `s`.`name`             AS `department_name`,
    `q`.`title`            AS `title`,
    `a`.`text`             AS `text`,
    `a`.`score`            AS `score`,
    `v`.`voter_id`         AS `voter_id`,
    sum(`a`.`score`)       AS `sum_score`,
    count(`a`.`score`)     AS `count_answer`
  FROM ((((`hr`.`vote` `v`
    JOIN `hr`.`question` `q` ON ((`v`.`question_id` = `q`.`id`))) JOIN `hr`.`answer` `a`
      ON ((`v`.`answer_id` = `a`.`id`))) LEFT JOIN `hr`.`personal` `p` ON ((`v`.`candidate_id` = `p`.`id`))) LEFT JOIN
    `hr`.`structure` `s` ON ((`v`.`department_id` = `s`.`id`)))
  GROUP BY `v`.`test_id`, `q`.`question_type_id`, `v`.`candidate_id`, `v`.`department_id`, `v`.`question_id`,
    `v`.`answer_id`
  ORDER BY `v`.`question_id`, sum(`a`.`score`) DESC;
