CREATE VIEW view_test_question_type AS
  SELECT DISTINCT
    `hr`.`question`.`test_id`          AS `test_id`,
    `hr`.`question`.`question_type_id` AS `question_type_id`
  FROM `hr`.`question`;
